var structosmo__crc32gen__code =
[
    [ "bits", "structosmo__crc32gen__code.html#ab7ea0542721265f02d540fc95fb48fda", null ],
    [ "init", "structosmo__crc32gen__code.html#ad139d035aff276d724db17c41b2147d8", null ],
    [ "poly", "structosmo__crc32gen__code.html#a38fbc53e41d3181a2123c62253f9ee25", null ],
    [ "remainder", "structosmo__crc32gen__code.html#aa0fc5a5c0a648855bae5d975fc8829c1", null ]
];